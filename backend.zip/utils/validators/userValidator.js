const slugify = require("slugify");
const bcrypt = require("bcryptjs");
const { check, body, param } = require("express-validator");
const validatorMiddleware = require("../../middlewares/validatorMiddleware");
const User = require("../../models/userModel");

exports.createUserValidator = [
  check("name")
    .notEmpty()
    .withMessage("User required")
    .isLength({ min: 3 })
    .withMessage("Too short User name")
    .custom((val, { req }) => {
      req.body.slug = slugify(val);
      return true;
    }),

  check("username")
    .optional()
    .isLength({ min: 3, max: 30 })
    .withMessage("Username must be between 3 and 30 characters")
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage("Username can only contain letters, numbers, and underscores")
    .custom((val) =>
      User.findOne({ username: val }).then((user) => {
        if (user) {
          return Promise.reject(new Error("Username already taken"));
        }
      })
    ),

  check("email")
    .notEmpty()
    .withMessage("Email required")
    .isEmail()
    .withMessage("Invalid email address")
    .custom((val) =>
      User.findOne({ email: val }).then((user) => {
        if (user) {
          return Promise.reject(new Error("E-mail already in user"));
        }
      })
    ),

  check("password")
    .notEmpty()
    .withMessage("Password required")
    .isLength({ min: 6 })
    .withMessage("Password must be at least 6 characters")
    .custom((password, { req }) => {
      if (password !== req.body.passwordConfirm) {
        throw new Error("Password Confirmation incorrect");
      }
      return true;
    }),

  check("passwordConfirm")
    .notEmpty()
    .withMessage("Password confirmation required"),

  check("phone")
    .optional()
    .custom((val) => {
      if (!val || typeof val !== "string") return true;
      const cleaned = val.replace(/\s+/g, "").replace(/^\+/, "");
      if (!/^\d{9,15}$/.test(cleaned)) {
        throw new Error("رقم الهاتف غير صالح. استخدم 9-15 رقمًا مع أو بدون +");
      }
      return true;
    }),

  check("profileImg").optional(),
  check("role").optional(),

  validatorMiddleware,
];

exports.getUserValidator = [
  check("id").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.updateUserValidator = [
  check("id").isMongoId().withMessage("Invalid User id format"),
  body("name")
    .optional()
    .custom((val, { req }) => {
      req.body.slug = slugify(val);
      return true;
    }),
  check("email")
    .notEmpty()
    .withMessage("Email required")
    .isEmail()
    .withMessage("Invalid email address")
    .custom((val) =>
      User.findOne({ email: val }).then((user) => {
        if (user) {
          return Promise.reject(new Error("E-mail already in user"));
        }
      })
    ),
  check("phone")
    .optional()
    .custom((val) => {
      if (!val || typeof val !== "string") return true;
      const cleaned = val.replace(/\s+/g, "").replace(/^\+/, "");
      if (!/^\d{9,15}$/.test(cleaned)) {
        throw new Error("رقم الهاتف غير صالح. استخدم 9-15 رقمًا مع أو بدون +");
      }
      return true;
    }),

  check("profileImg").optional(),
  check("role").optional(),
  validatorMiddleware,
];

exports.changeUserPasswordValidator = [
  check("id").isMongoId().withMessage("Invalid User id format"),
  body("currentPassword")
    .notEmpty()
    .withMessage("You must enter your current password"),
  body("passwordConfirm")
    .notEmpty()
    .withMessage("You must enter the password confirm"),
  body("password")
    .notEmpty()
    .withMessage("You must enter new password")
    .custom(async (val, { req }) => {
      // 1) Verify current password
      const user = await User.findById(req.params.id);
      if (!user) {
        throw new Error("There is no user for this id");
      }
      const isCorrectPassword = await bcrypt.compare(
        req.body.currentPassword,
        user.password
      );
      if (!isCorrectPassword) {
        throw new Error("Incorrect current password");
      }

      // 2) Verify password confirm
      if (val !== req.body.passwordConfirm) {
        throw new Error("Password Confirmation incorrect");
      }
      return true;
    }),
  validatorMiddleware,
];

exports.deleteUserValidator = [
  check("id").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.updateLoggedUserValidator = [
  body("name")
    .optional()
    .custom((val, { req }) => {
      req.body.slug = slugify(val);
      return true;
    }),

  body("username")
    .optional()
    .isLength({ min: 3, max: 30 })
    .withMessage("Username must be between 3 and 30 characters")
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage("Username can only contain letters, numbers, and underscores")
    .custom((val, { req }) =>
      User.findOne({ username: val }).then((user) => {
        if (user && user._id.toString() !== req.user._id.toString()) {
          return Promise.reject(new Error("Username already taken"));
        }
      })
    ),
  body("email")
    .optional()
    .isEmail()
    .withMessage("Invalid email address")
    .custom((val, { req }) => {
      if (!val) return true;
      return User.findOne({ email: val }).then((user) => {
        if (user && user._id.toString() !== req.user._id.toString()) {
          return Promise.reject(new Error("E-mail already in use"));
        }
      });
    }),
  body("phone")
    .optional()
    .custom((val) => {
      if (!val || typeof val !== "string") return true;
      const cleaned = val.replace(/\s+/g, "").replace(/^\+/, "");
      if (!/^\d{9,15}$/.test(cleaned)) {
        throw new Error("رقم الهاتف غير صالح. استخدم 9-15 رقمًا مع أو بدون +");
      }
      return true;
    }),

  validatorMiddleware,
];

exports.addToFavoritesValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.removeFromFavoritesValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.sendFriendRequestValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.acceptFriendRequestValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.rejectFriendRequestValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.cancelFriendRequestValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.removeFriendValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.blockUserValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  validatorMiddleware,
];

exports.reportUserValidator = [
  check("userId").isMongoId().withMessage("Invalid User id format"),
  body("reason").optional().isString().withMessage("Reason must be a string"),
  body("details").optional().isString().withMessage("Details must be a string"),
  validatorMiddleware,
];

exports.sendGalleryViewRequestValidator = [
  param("userId").isMongoId().withMessage("Invalid user id format"),
  validatorMiddleware,
];

exports.acceptGalleryViewRequestValidator = [
  param("requestId").isMongoId().withMessage("Invalid request id format"),
  validatorMiddleware,
];

exports.rejectGalleryViewRequestValidator = [
  param("requestId").isMongoId().withMessage("Invalid request id format"),
  validatorMiddleware,
];
