const express = require("express");
const {
  submitIdentityVerification,
  getUserVerificationStatus,
  getPendingVerificationRequests,
  getAllVerificationRequests,
  reviewVerificationRequest,
  getVerificationRequestDetails,
  getUserVerificationHistory,
  getVerificationStats,
} = require("../services/identityVerificationService");

const {
  submitIdentityVerificationValidator,
  reviewVerificationRequestValidator,
} = require("../utils/validators/identityVerificationValidator");

const uploadImageMiddleware = require("../middlewares/uploadImageMiddleware");
const {
  protectVerificationFileAccess,
  sendVerificationFile,
} = require("../middlewares/verificationFileAccess");
const authService = require("../services/authService");
const adminService = require("../services/adminService");

const router = express.Router();

router.get(
  "/files/:filename",
  protectVerificationFileAccess,
  sendVerificationFile,
);

// User routes - require user authentication and phone verification
router.post(
  "/submit",
  authService.protect,
  authService.requirePhoneVerified,
  uploadImageMiddleware.uploadMixOfImages([
    { name: 'documents[0][url]', maxCount: 1 },
    { name: 'documents[1][url]', maxCount: 1 },
    { name: 'documents[2][url]', maxCount: 1 },
  ]),
  uploadImageMiddleware.validateUploadedBuffers,
  submitIdentityVerificationValidator,
  submitIdentityVerification
);
router.get("/status", authService.protect, authService.requirePhoneVerified, getUserVerificationStatus);
router.get("/history", authService.protect, authService.requirePhoneVerified, getUserVerificationHistory);

// Admin only routes - require admin authentication only
router.get("/requests", adminService.protectAdmin, getPendingVerificationRequests);
router.get("/all-requests", adminService.protectAdmin, getAllVerificationRequests);
router.get("/requests/:id", adminService.protectAdmin, getVerificationRequestDetails);
router.put(
  "/requests/:id/review",
  adminService.protectAdmin,
  reviewVerificationRequestValidator,
  reviewVerificationRequest
);
router.get("/stats", adminService.protectAdmin, getVerificationStats);

module.exports = router;
