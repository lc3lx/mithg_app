const crypto = require("crypto");

const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const asyncHandler = require("express-async-handler");
const ApiError = require("../utils/apiError");
const sendEmail = require("../utils/sendEmail");
const createToken = require("../utils/createToken");

const User = require("../models/userModel");
const Notification = require("../models/notificationModel");

const getClientIp = (req) =>
  (req.headers["x-forwarded-for"] || req.ip || "")
    .toString()
    .split(",")[0]
    .trim();

const getClientDeviceId = (req) =>
  (
    req.headers["x-device-id"] ||
    req.body?.deviceId ||
    req.body?.device_id ||
    req.query?.deviceId ||
    req.query?.device_id ||
    ""
  )
    .toString()
    .trim();

const isUserCurrentlyBlocked = (user, now = new Date()) =>
  !!(user?.isBlocked && user?.blockedUntil && user.blockedUntil > now);

const isFullOrPermanentBlock = (user) => {
  if (!user || !user.blockedUntil) return false;
  const hasFullIdentifiers =
    !!user.blockedIdentifiers?.phone ||
    (user.blockedIdentifiers?.ips || []).length > 0 ||
    (user.blockedIdentifiers?.deviceIds || []).length > 0;
  const yearsAhead = user.blockedUntil.getFullYear() - new Date().getFullYear();
  const isPermanentStyle = yearsAhead >= 10;
  return hasFullIdentifiers || isPermanentStyle;
};

const buildBlockMessage = (user) => {
  if (isFullOrPermanentBlock(user)) {
    return "تم حظر حسابك بشكل كامل. تواصل مع الدعم.";
  }
  return `الحساب محظور حتى ${user.blockedUntil.toLocaleString(
    "ar-SA",
  )}. تواصل مع الدعم.`;
};

const sendBlockedResponse = (res, user) =>
  res.status(403).json({
    status: "fail",
    code: "ACCOUNT_BLOCKED",
    message: buildBlockMessage(user),
    blockedUntil: user?.blockedUntil || null,
    fullBlock: isFullOrPermanentBlock(user),
  });

const findActiveIdentifierBlock = async ({ phone, ip, deviceId }) => {
  const or = [];
  if (phone) or.push({ "blockedIdentifiers.phone": phone });
  if (ip) or.push({ "blockedIdentifiers.ips": ip });
  if (deviceId) or.push({ "blockedIdentifiers.deviceIds": deviceId });
  if (or.length === 0) return null;

  return User.findOne({
    isBlocked: true,
    blockedUntil: { $gt: new Date() },
    blockedIdentifiers: { $exists: true, $ne: null },
    $or: or,
  }).select("_id blockedUntil blockedIdentifiers");
};

// @desc    Signup
// @route   POST /api/v1/auth/signup
// @access  Public
exports.signup = asyncHandler(async (req, res, next) => {
  try {
    const user = await User.create({
      name: req.body.name,
      username: req.body.username,
      email: req.body.email,
      phone: req.body.phone,
      password: req.body.password,
    });

    // إشعار ترحيبي تلقائي من الإدارة لكل مستخدم جديد.
    try {
      await Notification.createNotification({
        user: user._id,
        type: "welcome",
        title: "رسالة من الإدارة",
        message:
          "السلام عليكم نحن هنا لخدمتكم يمكنكم الاستفسار عن اي خدمة في اي وقت",
      });
    } catch (notificationError) {
      console.error(
        "Signup welcome notification error:",
        notificationError.message,
      );
    }

    const token = createToken(user._id);
    res.status(201).json({ data: user, token });
  } catch (err) {
    if (err.code === 11000) {
      const key = err.keyPattern
        ? Object.keys(err.keyPattern)[0]
        : err.keyValue
        ? Object.keys(err.keyValue)[0]
        : null;
      if (key === "phone") {
        return next(
          new ApiError(
            "الرقم مستخدم من قبل. سجّل الدخول أو استخدم رقماً آخر.",
            400,
          ),
        );
      }
      if (key === "email") {
        return next(
          new ApiError(
            "البريد الإلكتروني مستخدم من قبل. سجّل الدخول أو استخدم بريداً آخر.",
            400,
          ),
        );
      }
      if (key === "username") {
        return next(
          new ApiError("اسم المستخدم مستخدم من قبل. اختر اسماً آخر.", 400),
        );
      }
      return next(
        new ApiError(
          "البيانات المدخلة مكررة. تحقق من الرقم أو البريد أو اسم المستخدم.",
          400,
        ),
      );
    }
    throw err;
  }
});

// @desc    Login
// @route   GET /api/v1/auth/login
// @access  Public
exports.login = asyncHandler(async (req, res, next) => {
  // 1) check if password and email in the body (validation)
  // 2) check if user exist & check if password is correct
  const user = await User.findOne({ email: req.body.email });

  if (!user) {
    return next(new ApiError("Invalid email or user not registered", 401));
  }
  if (user.active === false) {
    return next(
      new ApiError("الحساب معطّل أو محذوف. تواصل مع الدعم لاستعادته.", 403),
    );
  }
  if (!(await bcrypt.compare(req.body.password, user.password))) {
    return next(new ApiError("كلمة المرور غير صحيحة", 401));
  }

  // التحقق من الحظر (حساب أو حظر شامل: جوال / IP / جهاز)
  const now = new Date();
  if (isUserCurrentlyBlocked(user, now)) {
    return sendBlockedResponse(res, user);
  }
  const clientIp = getClientIp(req);
  const clientDeviceId = getClientDeviceId(req);
  const blockedByIdentifiers = await findActiveIdentifierBlock({
    phone: user.phone,
    ip: clientIp,
    deviceId: clientDeviceId,
  });
  if (blockedByIdentifiers) {
    return sendBlockedResponse(res, blockedByIdentifiers);
  }

  // حفظ آخر IP و deviceId لتستخدم عند الحظر الشامل
  user.lastLoginIp = clientIp || user.lastLoginIp;
  if (clientDeviceId) user.lastDeviceId = clientDeviceId;
  await user.save({ validateBeforeSave: false });

  // 3) generate token
  const token = createToken(user._id);

  // Delete password from response
  delete user._doc.password;
  // 4) send response to client side
  res.status(200).json({ data: user, token });
});

// @desc   make sure the user is logged in
exports.protect = asyncHandler(async (req, res, next) => {
  // 1) Check if token exist, if exist get
  let token;
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    token = req.headers.authorization.split(" ")[1];
  }
  if (!token) {
    return next(
      new ApiError("أنت غير مسجل. يرجى تسجيل الدخول للحصول على الوصول.", 401),
    );
  }

  // 2) Verify token (no change happens, expired token)
  const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

  // 3) Check if user exists and is active
  const currentUser = await User.findById(decoded.userId);
  if (!currentUser) {
    return next(
      new ApiError("المستخدم الذي ينتمي إلى هذا الرمز لم يعد موجودا", 401),
    );
  }
  if (currentUser.active === false) {
    return next(
      new ApiError("الحساب معطّل أو محذوف. لا يمكنك الوصول لهذه الصفحة.", 403),
    );
  }
  const now = new Date();
  if (isUserCurrentlyBlocked(currentUser, now)) {
    return sendBlockedResponse(res, currentUser);
  }

  const clientIp = getClientIp(req) || currentUser.lastLoginIp || "";
  const clientDeviceId = getClientDeviceId(req) || currentUser.lastDeviceId || "";
  const blockedByIdentifiers = await findActiveIdentifierBlock({
    phone: currentUser.phone,
    ip: clientIp,
    deviceId: clientDeviceId,
  });
  if (blockedByIdentifiers) {
    return sendBlockedResponse(res, blockedByIdentifiers);
  }

  // حدّث آخر معرفات للوصول كي يبقى الحظر الشامل فعالاً بدقة.
  const shouldUpdateIp = clientIp && clientIp !== currentUser.lastLoginIp;
  const shouldUpdateDevice =
    clientDeviceId && clientDeviceId !== currentUser.lastDeviceId;
  if (shouldUpdateIp || shouldUpdateDevice) {
    if (shouldUpdateIp) currentUser.lastLoginIp = clientIp;
    if (shouldUpdateDevice) currentUser.lastDeviceId = clientDeviceId;
    await currentUser.save({ validateBeforeSave: false });
  }

  // 4) Check if user change his password after token created
  if (currentUser.passwordChangedAt) {
    const passChangedTimestamp = parseInt(
      currentUser.passwordChangedAt.getTime() / 1000,
      10,
    );
    // Password changed after token created (Error)
    if (passChangedTimestamp > decoded.iat) {
      return next(
        new ApiError(
          "تم تغيير كلمة المرور الخاص بالمستخدم مؤخرا. يرجى تسجيل الدخول مرة أخرى.",
          401,
        ),
      );
    }
  }

  req.user = currentUser;
  next();
});

// @desc    يمنع دخول المستخدم للتطبيق حتى يتحقق من OTP (رقم الهاتف)
// @use     بعد protect على مسارات المستخدم فقط (ليس الأدمن أو Auth)
exports.requirePhoneVerified = (req, res, next) => {
  if (!req.user) {
    return next(
      new ApiError("أنت غير مسجل. يرجى تسجيل الدخول للحصول على الوصول.", 401),
    );
  }
  if (req.user.phoneVerified === true) {
    return next();
  }
  return res.status(403).json({
    code: "PHONE_NOT_VERIFIED",
    message: "يجب التحقق من رقم الهاتف أولاً",
    phone: req.user.phone || null,
    registrationStep: req.user.registrationStep ?? 0,
  });
};

// @desc    Authorization (User Permissions)
// ["admin", "manager"]
exports.allowedTo = (...roles) =>
  asyncHandler(async (req, res, next) => {
    // 1) access roles
    // 2) access registered user (req.user.role)
    if (!roles.includes(req.user.role)) {
      return next(new ApiError("ليس لديك صلاحية للوصول لهذه الصفحة", 403));
    }
    next();
  });

// @desc    Forgot password
// @route   POST /api/v1/auth/forgotPassword
// @access  Public
exports.forgotPassword = asyncHandler(async (req, res, next) => {
  // 1) Get user by email
  const user = await User.findOne({ email: req.body.email });
  if (!user) {
    return res.status(200).json({
      status: "Success",
      message:
        "إذا كان البريد مسجلاً لدينا ستصلك رسالة تحتوي الرمز.",
    });
  }
  const resetCode = crypto.randomInt(100000, 1000000).toString();
  const hashedResetCode = crypto
    .createHash("sha256")
    .update(resetCode)
    .digest("hex");

  // Save hashed password reset code into db
  user.passwordResetCode = hashedResetCode;
  // Add expiration time for password reset code (10 min)
  user.passwordResetExpires = Date.now() + 10 * 60 * 1000;
  user.passwordResetVerified = false;

  await user.save();

  // 3) Send the reset code via email
  const message = `السلام عليكم ${user.name},\n أحصلنا على طلب لإعادة تعيين كلمة المرور على حسابك في Mithaqsyr. \n ${resetCode} \n أدخل هذا الرمز لإنهاء الإعادة تعيين. \n شكرا لمساعدتنا في الحفاظ على حسابك آمن.\n فريق Mithaqsyr`;
  try {
    await sendEmail({
      email: user.email,
      subject: "رمز تعيين كلمة المرور (متوفر لمدة 10 دقيقة)",
      message,
    });
  } catch (err) {
    user.passwordResetCode = undefined;
    user.passwordResetExpires = undefined;
    user.passwordResetVerified = undefined;

    await user.save();
    return next(new ApiError("حدث خطأ في إرسال البريد الإلكتروني", 500));
  }

  res
    .status(200)
    .json({
      status: "Success",
      message: "تم إرسال رمز التعيين إلى البريد الإلكتروني",
    });
});

// @desc    Verify password reset code
// @route   POST /api/v1/auth/verifyResetCode
// @access  Public
exports.verifyPassResetCode = asyncHandler(async (req, res, next) => {
  // 1) Get user based on reset code
  const hashedResetCode = crypto
    .createHash("sha256")
    .update(req.body.resetCode)
    .digest("hex");

  const user = await User.findOne({
    passwordResetCode: hashedResetCode,
    passwordResetExpires: { $gt: Date.now() },
  });
  if (!user) {
    return next(
      new ApiError("رمز التعيين غير صحيح أو منتهي الصلاحية", 400),
    );
  }

  // 2) Reset code valid
  user.passwordResetVerified = true;
  await user.save();

  res.status(200).json({
    status: "Success",
  });
});

// @desc    Reset password
// @route   POST /api/v1/auth/resetPassword
// @access  Public
exports.resetPassword = asyncHandler(async (req, res, next) => {
  // 1) Get user based on email
  const user = await User.findOne({ email: req.body.email });
  if (!user) {
    return next(
      new ApiError(
        `لا يوجد مستخدم بهذا البريد الإلكتروني ${req.body.email}`,
        404,
      ),
    );
  }

  // 2) Check if reset code verified
  if (!user.passwordResetVerified) {
    return next(new ApiError("رمز التعيين غير مؤكد", 400));
  }

  user.password = req.body.newPassword;
  user.passwordResetCode = undefined;
  user.passwordResetExpires = undefined;
  user.passwordResetVerified = undefined;

  await user.save();

  // 3) if everything is ok, generate token
  const token = createToken(user._id);
  res.status(200).json({ token });
});
