const mongoose = require("mongoose");
const { sendPushToUser } = require("../utils/pushNotification");
const sendEmail = require("../utils/sendEmail");
const User = require("./userModel");

const notificationSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
      required: [true, "Notification must belong to user"],
    },
    type: {
      type: String,
      enum: [
        // User interaction notifications
        "friend_request",
        "friend_request_accepted",
        "friend_request_rejected",
        "new_message",
        "post_like",
        "post_comment",
        "profile_view",
        "match_suggestion",
        "people_nearby",
        "security_update",
        "messaging_request",
        "messaging_request_accepted",
        "messaging_request_rejected",
        "gallery_view",
        "gallery_view_request",
        "gallery_view_accepted",
        "gallery_view_rejected",
        "identity_verification_approved",
        "identity_verification_rejected",
        "subscription_request_approved",
        "subscription_request_rejected",
        // Admin broadcast notifications
        "update",
        "promotion",
        "security",
        "welcome",
        "maintenance",
        "general",
      ],
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    message: {
      type: String,
      required: true,
      trim: true,
    },
    recipientType: {
      type: String,
      enum: ["specific", "all", "premium", "new_users", "inactive"],
      default: "specific",
    },
    status: {
      type: String,
      enum: ["draft", "scheduled", "sent", "cancelled"],
      default: "sent",
    },
    scheduledAt: Date,
    sentAt: {
      type: Date,
      default: Date.now,
    },
    recipientsCount: {
      type: Number,
      default: 1,
      min: 0,
    },
    openedCount: {
      type: Number,
      default: 0,
      min: 0,
    },
    // Related entities
    relatedUser: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
    },
    relatedPost: {
      type: mongoose.Schema.ObjectId,
      ref: "Post",
    },
    relatedChat: {
      type: mongoose.Schema.ObjectId,
      ref: "Chat",
    },
    relatedMessage: {
      type: mongoose.Schema.ObjectId,
      ref: "Message",
    },
    // Notification status
    isRead: {
      type: Boolean,
      default: false,
    },
    readAt: Date,
    openRate: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },
    // Push notification data
    pushSent: {
      type: Boolean,
      default: false,
    },
    pushSentAt: Date,
    // Custom data for the notification
    data: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  { timestamps: true }
);

// Indexes
notificationSchema.index({ user: 1, createdAt: -1 });
notificationSchema.index({ user: 1, isRead: 1 });
notificationSchema.index({ type: 1 });
notificationSchema.index({ status: 1 });
notificationSchema.index({ scheduledAt: 1 }, { sparse: true });

// Populate related entities when querying
notificationSchema.pre(/^find/, function (next) {
  this.populate({
    path: "relatedUser",
    select: "name profileImg isOnline",
  }).populate({
    path: "relatedPost",
    select: "title content",
  });
  next();
});

notificationSchema.post("save", async (doc) => {
  try {
    // أرسل الـ push فقط عندما تكون حالة الإشعار "sent".
    // هذا يمنع الإرسال المبكر/المكرر لإشعارات الأدمن أثناء البث أو الجدولة.
    if (!doc.pushSent && doc.status === "sent") {
      let relatedUserInfo = null;
      if (doc.relatedUser) {
        const u = await User.findById(doc.relatedUser)
          .select("name profileImg")
          .lean();
        if (u) {
          const profileImg =
            u.profileImg && !u.profileImg.startsWith("http")
              ? `${process.env.BASE_URL || ""}/uploads/users/${u.profileImg}`
              : u.profileImg;
          relatedUserInfo = {
            relatedUserName: u.name,
            relatedUserProfileImg: profileImg || undefined,
          };
        }
      }
      await sendPushToUser(doc.user, doc, relatedUserInfo);
      await doc.constructor.updateOne(
        { _id: doc._id },
        { pushSent: true, pushSentAt: new Date() }
      );
    }
  } catch (error) {
    console.error("[Notification push] failed:", error.message);
    // Do not mark pushSent — allows retry or manual inspection; avoids false "sent" state.
  }

  // إرسال نسخة من الإشعار إلى بريد المستخدم (ما عدا رسائل المحادثة لئلا يصل المستخدم أكثر من إشعار)
  if (doc.type !== "new_message") {
    (async () => {
      try {
        const user = await User.findById(doc.user).select("email").lean();
        if (!user || !user.email) return;
        await sendEmail({
          email: user.email,
          subject: `إشعار - ${doc.title}`,
          message: `${doc.title}\n\n${doc.message}\n\n---\nتطبيق ميثاق`,
        });
      } catch (err) {
        console.error("Notification email send error:", err.message);
      }
    })();
  }
});

// Auto-delete old notifications (keep only last 100 per user)
notificationSchema.statics.cleanupOldNotifications = async function (userId) {
  const notifications = await this.find({ user: userId })
    .sort({ createdAt: -1 })
    .skip(100);

  if (notifications.length > 0) {
    await this.deleteMany({
      _id: { $in: notifications.map((n) => n._id) },
    });
  }
};

// Create notification method
notificationSchema.statics.createNotification = async function (data) {
  const notification = await this.create(data);

  // Cleanup old notifications
  await this.cleanupOldNotifications(data.user);

  return notification;
};

module.exports = mongoose.model("Notification", notificationSchema);
